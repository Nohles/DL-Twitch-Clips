# Download Clips Extension for Twitch

DL-Twitch-Clips is a chrome extension that allows you to download clips from Twitch.tv

-It adds a button on the clips.twitch.tv page that allows you to download clips
-It adds a button on the twitch.tv/(channel)/clip page that allows you to download clips

![chrome_7uJXm6Xnl3](https://user-images.githubusercontent.com/72172038/198835222-2da906e3-7734-41dc-81e3-1d05753d441c.png)

![chrome_Aexj9sI9Ih](https://user-images.githubusercontent.com/72172038/198835223-a06e2717-4f1d-4b31-8bd8-b69e9fc1e2a4.png)

-when you click on the button it will download the clip to you Downloads with the title of the clip as the file name.
![chrome_0Rp27mI7xK](https://user-images.githubusercontent.com/72172038/198835331-8931ad3b-55c4-40ee-a2dc-76e3607d1ec4.png)


-It adds a button on the m.twitch.tv page to take you to the desktop version page

![chrome_W4WL4zL8oz](https://user-images.githubusercontent.com/72172038/198835362-5daa78db-83a3-4206-b036-00ab015ff0e1.png)

Created this chrome extension using typescript and learned how to create a chrome extension using the Manifest v3.
https://chrome.google.com/webstore/detail/download-twitch-clips/ceidjopggcgjldgpfkooaoogcpihpoff?hl=en&authuser=1
