// adding a new bookmark row to the popup

//const setBookmarkAttributes = () => {};

// document.addEventListener("DOMContentLoaded", () => {});
